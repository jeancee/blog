CREATE - make new
RETRIEVE - get -- list/search
UPDATE - edit
DELETE - delete

List/Search